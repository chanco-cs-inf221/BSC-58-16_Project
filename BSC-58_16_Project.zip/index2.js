


function openForm() {
    document.getElementById("myForm").style.display = "block";
}
  
function closeForm() {
    document.getElementById("myForm").style.display = "none";
}
function nextPage(){
    window.location.href = "index3.html";
}
/*function buyLaptop() {
    alert ("Thank you for your purchase. You will receive within 24 hours")
}*/


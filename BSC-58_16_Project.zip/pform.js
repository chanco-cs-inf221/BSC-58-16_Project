function random(){
    var phone=document.getElementById('phone');
    var priceBox=document.getElementById('priceBox');
    if(phone.selectedIndex==0){
        priceBox.value="";
    }
    else (if(phone.selectedIndex==1){
        priceBox.value="K219 065";
    }
    else if(phone.selectedIndex==2){
        priceBox.value="K426 293";
    }
    else{
        priceBox.value="K426 293";
    }
}

/*function random(){
    var x=document.getElementById('phone').value;
    if(x==="Google Pixel 2"){
        document.write("<b>K219 065</b>");
    }
    else if(x==="Google Pixel 3 XL"){
        document.write("<b>K426 293</b>");
    }
    else{
        document.write("<b>K696 493</b>");
    }

}*/



/*function random(p1,p2,p3){
    var p1=document.getElementById('phone').value;
    var p2=document.getElementById('phone').value;
    var p3=document.getElementById('phone').value;
}*/

